/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
  Lezione 11
	
	UDP Server  
  
  Esempio di semplice server UDP in grado ri rispondere alle richieste di pi� client.
  1. Il server ascolta le richieste al numero di porta assegnata alla variabile porta (esempio: 1234)
  2. il server crea un messaggio di risposta che ottiene semplicemente
     convertendo in maiuscolo il messaggio di richiesta del client.
*/

import java.io.*; 
import java.net.*; 
class UDPServer { 
  public static void main(String args[]) throws Exception{
	 final int portaServer = 1234;
    DatagramSocket socketServer = new DatagramSocket(portaServer);
    System.out.println("Server UDP in ascolto sulla porta "+portaServer);
    while(true){
			byte[] richiesta_b = new byte[1024]; 
      DatagramPacket richiesta_pack = new DatagramPacket(richiesta_b,richiesta_b.length); /* crea un oggetto di tipo DatagramPacket per contenere il messaggio di richiesta del client */
      socketServer.receive(richiesta_pack); /* receive � un metodo bloccante: il server resta sospeso
fino a quando arriva un messaggio da un client */
      String richiesta = new String(richiesta_pack.getData());
      InetAddress indirizzoIPClient = richiesta_pack.getAddress(); 
      int portaClient = richiesta_pack.getPort(); 
      String risposta = richiesta.trim().toUpperCase();
      byte[] risposta_b = new byte[risposta.length()]; 
      risposta_b = risposta.getBytes(); 
      DatagramPacket risposta_pack = new DatagramPacket(risposta_b,risposta.length(),indirizzoIPClient, portaClient);
      socketServer.send(risposta_pack);
    }
  }
}
