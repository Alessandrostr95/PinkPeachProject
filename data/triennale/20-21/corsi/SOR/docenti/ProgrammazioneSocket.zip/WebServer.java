/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
	Ultima modifica: 1/04/2020
  Esempio di semplice server HTTP.
  Il server gestisce solo il metodo GET.
*/

import java.io.*; 
import java.net.*; 
import java.util.*; 
class WebServer { 
  public static void main(String argv[]) {
    String richiesta;
    String nomeFile;
		
    int porta=80;
    try {
      /* crea un socket di ascolto con numero di porta=80 */
      ServerSocket ascoltoSocket = new ServerSocket(porta);
      System.out.println("Server http in ascolto sulla porta " + porta);
      while(true){ 
        /* Crea un socket per la connessione. La chiamata del metodo accept �
        * bloccante. Il processo torna nello stato attivo quando un client invia una richiesta
        * di connessione alla porta di ascolto. */
        Socket connectionSocket = ascoltoSocket.accept(); 
        System.out.println("richiesta da: "+connectionSocket.getInetAddress());
        /* in_client � uno stream da cui � possibile prelevare i dati che vengono
        * inviati dal client. 
        */
        BufferedReader in_client = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
        /* out � lo stream in uscita sul quale � possibile scrivere i dati da inviare 
        * al client.
        */
        DataOutputStream out = new DataOutputStream(connectionSocket.getOutputStream()); 
        /* il metodo readLine consente la lettura di una riga di dati dallo stream di ingresso */
        richiesta = in_client.readLine();
        System.out.println("richiesta: " + richiesta);
        /* intestazione � un oggetto di tipo ArrayList, usato per memorizzare le linee
           di intestazione del messaggio di richiesta provenienti da un client.
           L'uso dell'ArrayList, in questo esempio non � strettamente necessario ma potrebbe
           essere utile per estendere le funzionalit� del programma.
        */
        ArrayList<String> intestazione = new ArrayList<String>();
        String linea=".";
        int i=0;
        /* Il ciclo seguente visualizza le linee di intestazione del messaggio di richiesta */
        while (! linea.equals("")){
          linea = in_client.readLine();
              
          intestazione.add(i,linea);
          System.out.println("intestazione " + i + ": " + linea);
          i++;  
        }   
        System.out.println(); // scrive una riga vuota
      
        /* La linea di richiesta di un messaggio di richiesta http ha il formato: 
        * | METODO  FILE_RICHIESTO  PROTOCOLLO |
        * ad esempio: GET /home.html HTTP/1.1
        */
      
        /* Passando la String richiesta al costruttore di StringTokenizer
           si ottiene la frammentazione della stringa in parole separate dal
           carattere spazio. Ad esempio se richiesta = "GET /home.html HTTP/1.1"
           si ottiene una lista di tre parole GET, /home.html e HTTP/1.1
           La lista pu� essere scandita chiamando il metodo nextToken della 
           classe StringTokenizer, che ogni volta ritorner� una parola della stringa.
        */
       
        StringTokenizer lineaRichiesta = new StringTokenizer(richiesta);
      
        String content="Content-Type: ";
        if (lineaRichiesta.nextToken().equals("GET")) { 
          nomeFile= lineaRichiesta.nextToken();
          if (nomeFile.equals("/")) 
            nomeFile="home.html";
          if (nomeFile.startsWith("/") == true )
            nomeFile = nomeFile.substring(1); /* elimina il carattere / dal nome del file */ 
          File file = new File(nomeFile); /* crea un oggetto File per effettuare operazioni ed ottenere le propriet� del file */
          if ( file.exists()) {
             /* se il file richiesto esiste viene eseguito questo blocco */ 
            int dimFile = (int)file.length(); /* dimensione del file richiesto */
						Date data = new Date(file.lastModified()); /* necessario per il get condizionale */
            FileInputStream in_file = new FileInputStream(nomeFile) ; /* crea uno stream per leggere il file */
            byte[] file_b = new byte[dimFile]; /* crea un array di byte per contenere il file richiesto */
            in_file.read(file_b); /* memorizza il file nell'array di byte file_b */
            /* Ora si costruisce il messaggio di risposta HTTP */
            out.writeBytes("HTTP/1.1 200 OK \r\n"); /* invia la linea di stato del messaggio HTTP di risposta */ 
            
						if (nomeFile.endsWith(".htm")||nomeFile.endsWith(".html"))
						  content+="text/html";
						else if (nomeFile.endsWith(".jpg"))
              content+="image/jpeg"; /* linea di intestazione: il contenuto del file � un immagine jpg */
            else if (nomeFile.endsWith (".gif") )
						  content+="image/gif";
						else
							content+="text/html";
						
            out.writeBytes(content+"\r\n"); /* linea di intestazione: il contenuto del file � un'immagine gif */
            out.writeBytes("Content-Length: " + dimFile + "\r\n"); /* linea di intestazione: dimensione del file */out.writeBytes("Last-Modified: "  + data +"\r\n");                   
            out.writeBytes("\r\n"); /* invia la linea vuota che precede il corpo dell'entit� */
            out.write(file_b, 0, dimFile); /* invia il corpo dell'entit� (file richiesto) */
          }
          else { /* il file non esiste, invia la linea di stato con codice 404 */
            out.writeBytes("HTTP1.1 404 not_found \r\n");
          }
        
          connectionSocket.close();
        }
        else 
          System.out.println("Messaggio di richiesta non valido"); /* il programma gestisce solo il metodo GET */
      }
    } catch (Exception e){
      e.printStackTrace(); // visualizza messaggio diagnostico nel caso di eccezione
    }
  }
}