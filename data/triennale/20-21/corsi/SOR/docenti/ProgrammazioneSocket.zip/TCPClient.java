/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
  TCP client 
  
  Esempio di client TCP.
  1. Il client instaura una connessione TCP con il server.
  2. Legge da tastiera una frase e la invia al server.
  3. Visualizza sullo schermo la risposta che ottiene dal server.
  
  Il programma termina se si digita la parola exit.
*/
import java.io.*;
import java.net.*;
class TCPClient {
  public static void main(String arg[]) throws Exception{
    String nomeServer="localhost";
    int porta=1234; /* porta di ascolto del server */
    String richiesta="."; 
    String risposta;
    BufferedReader in_tastiera=new BufferedReader(new InputStreamReader(System.in));
    Socket clientSocket = new Socket(nomeServer, porta); /* instaura una connessione con il server (handshake)*/
    System.out.println("Porta locale: "+clientSocket.getLocalPort()); /* porta locale usata dal client.
    Questa porta � scelta automaticamente dal TCP */
    System.out.println("Porta remota: "+clientSocket.getPort()); /* porta remota del server */
    DataOutputStream out=new DataOutputStream(clientSocket.getOutputStream()); /* Stream di uscita connesso al socket */
    BufferedReader in_server=new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); /* Stream di ingresso connesso al socket */
    while (! richiesta.equals("exit")){
      System.out.print("Scrivi una frase: ");
      richiesta=in_tastiera.readLine(); /* metodo bloccante. Il processo resta sospeso fino a che si preme invio da tastiera */
      // System.out.println("ho scritto la frase: "+richiesta);
      out.writeBytes(richiesta+"\n"); /* scrive il messaggio nello stream di uscita */
      risposta=in_server.readLine(); /* metodo bloccante: il client resata sospeso fino a quando       riceve un messaggio dal server */
    
      System.out.println("Risposta dal server: "+risposta); /* visualizza la risposta ottenuta dal server */
      
    }
    clientSocket.close(); // chiude la connessione
  }
}
 