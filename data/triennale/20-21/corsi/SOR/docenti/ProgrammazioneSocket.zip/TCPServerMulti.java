/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
	
  TCP server MultiThread
  
  Esempio di Server TCP MultiThread.
  Il server elabora messaggi provenienti da pi� client.
  Per ogni client viene creato un nuovo thread.
*/

import java.io.*;
import java.net.*;
public class TCPServerMulti {
  public static void main(String arg[]) throws Exception {
    int porta = 1234;  /* porta di ascolto */
    int i=1; // contatore client 
    ServerSocket ascoltoSocket = new ServerSocket(porta); /* crea un socket di ascolto per le richieste dei client */
    System.out.println("Server multithread in ascolto sulla porta "+ porta);
    while (true) {
      Socket connSocket = ascoltoSocket.accept(); /* metodo bloccante: il processo si sospende. Si
      riattiva quando giunge una richiesta da un client */
      System.out.println("Thread " + i + " local port: "+connSocket.getLocalPort() + " remote port: "+connSocket.getPort());/
      TCPServerThread st = new TCPServerThread(connSocket,i); /* crea un oggetto della classe TCPServerThread. Il costruttore ha due parametri. In particolare il primo crea un riferimento tra il socket connSocket, creato chiamando il metodo accept, e il socket privato della classe TCPServerThread */
      Thread th = new Thread(st); /* crea un oggetto della classe Thread  e passa al costruttore l'oggetto della classe TCPServerThread, di seguito implementata */
      th.start(); /* avvia il thread progettato: viene eseguito il metodo run di TCPServerThread */
      i++;/* incrementa contatore thread */
    }    

  }
}

/*
Un thread in Java pu� essere creato nel seguente modo:
 1. Si crea una classe (in questo esempio TCPServerThread) che implementa l'interfaccia Runnable.
 2. L'interfaccia Runnable possiede l'unico metodo run, il quale dovr� contenere il codice
   del thread. 
 3. Esternamente alla classe, si crea un oggetto della classe realizzata seguendo i punti 1 e 2. 
    In questo esempio viene creato l'oggetto st della classe TCPServerThread all'interno del
    metodo main della classe TCPServerMulti.
 4. Si crea un oggetto della classe Thread (th) e si passa al costruttore di questa l'oggetto creato nel    punto precedente: Thread th = new Thread(st);
5. si avvia il thread mediante il metodo start della classe Thread: th.start(), che eseguir� il metodo run della classe TCPServerThread.
*/
class TCPServerThread implements Runnable {
  private Socket connSocket; // socket di connessione
  private int id; // identificativo del thread
  private String richiesta; // messaggio di richiesta proveniente dal client
  private String risposta; // messaggio di risposta elaborato in risposta al client
  private BufferedReader in; // stream di ingresso al processo
  private DataOutputStream out; // stream di uscita
  public TCPServerThread(Socket conn, int n) {
    // costruttore
    connSocket=conn;
    id=n;  
    try {
      in=new BufferedReader(new InputStreamReader(connSocket.getInputStream())); // Stream di ingresso del socket
      out=new DataOutputStream(connSocket.getOutputStream());  //stream di uscita del socket 
    } 
    catch (IOException e) {  
      e.printStackTrace(); // visualizza messaggio diagnostico nel caso di eccezione
    }
  }
  public void run()  {
    richiesta=".";
    try { 
      while (! richiesta.equals("exit")) {
        richiesta=in.readLine();/* metodo bloccante: legge il messaggio di richiesta che arriva da un client */
        risposta="(thread "+ id +") " + richiesta.toUpperCase()+"\n"; // converte la stringa richiesta in maiuscolo
        out.writeBytes(risposta);/* invia la risposta al client mediante lo stream di uscita */
      }
    connSocket.close(); // chiusura del socket
    } 
    catch (IOException e) {  
      e.printStackTrace();
    }
  }

}

