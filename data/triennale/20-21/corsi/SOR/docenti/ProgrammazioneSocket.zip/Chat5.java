/* 
Chat per due.
© Pietro Frasca, Aprile 2015
pietro.frasca@uniroma2.it
USO:
	per lanciare l'app in modalità server: start java Chat5
	per lanciare l'app in modalità client: start java <indirizzo del servere> 
																				 specificare localhost per indirizzo del servere locale
*/
import java.io.*;
import java.net.*;

class Message implements Serializable{
	// eventuali altri campi del messaggio
	String text;
}

public class Chat5 {
	private final int porta=1234;
	private Message richiesta = null;
	private Message risposta = null;
	private BufferedReader inTastiera = null;
	private Socket sock = null;
	private ServerSocket servSock=null;
	private ObjectOutputStream oos=null;
	private ObjectInputStream ois=null;
	
	private class Sender implements Runnable {
		public void run () {
			try {
				while (true) {
					// richiesta=new Message();
					richiesta.text= inTastiera.readLine();
					oos.writeObject(richiesta);
				  oos.reset(); 
				}
			} catch (IOException e) {}
		}
	}
	
	private class Receiver implements Runnable {
		public void run() {
			try {
				while (true){
					risposta = (Message)ois.readObject();
					System.out.println("net: " + risposta.text);
				}
			} catch (Exception e) {}
		}	
	}
	
	public Chat5(String hostName) throws IOException {
		if (hostName.length()==0)
			listen();
		else	
			connect(hostName);
		
		richiesta=new Message();
		risposta=new Message();
		setStream();
		printInfo();
		Thread sendTh = new Thread(new Sender());	
		Thread rcvTh = new Thread(new Receiver());
		sendTh.start();
		rcvTh.start();
	}
	
	private void listen() throws IOException{ 
			servSock = new ServerSocket(porta);
			System.out.println("In ascolto sulla porta "+porta);
			sock = servSock.accept();
	}
	
	private void connect(String hostName)throws IOException{
			sock = new Socket(hostName, porta);
	}
		
	private void printInfo() {
			System.out.println("Connesso...");
			System.out.println("IP: " + sock.getInetAddress());
			System.out.println("Porta: " + sock.getPort());
	}
	
	private void setStream() throws IOException {
		inTastiera = new BufferedReader(new InputStreamReader(System.in));
		oos = new ObjectOutputStream(sock.getOutputStream());
		ois = new ObjectInputStream(sock.getInputStream());
	}
		
	public static void main(String args[]) throws Exception {
		
		if (args.length==0) {
			Chat5 chat = new Chat5("");
		} else {
			Chat5 chat = new Chat5(args[0]);
		}	
	}
}
