/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
  Lezione 10

  TCP Server (solo una richiesta)  
  
  Esempio di semplice server TCP in grado di rispondere alla richiesta di un solo client.
  Il server deve essere avviato prima del client.
  1. Il server ascolta le richieste al numero di porta assegnata alla variabile porta (esempio: 1234)
  2. il server crea un messaggio di risposta che ottiene semplicemente
     convertendo in maiuscolo il messaggio di richiesta del client.
  
  Il programma termina se il server riceve dal client la parola exit.
*/
import java.io.*;
import java.net.*;
class TCPServer {
  public static void main(String arg[]) throws Exception {
    String richiesta="", risposta; // messaggio ricevuto (richiesta) e messaggio elaborato (risposta)
    final int porta = 1234;  // numero di porta d'ascolto
    ServerSocket ascoltoSocket = new ServerSocket(porta); // socket di ascolto
    System.out.println("Server in ascolto sulla porta "+ porta);   
    Socket connSocket=ascoltoSocket.accept(); /* metodo bloccante: il processo sar� sospeso fino all'arrivo della richiesta del client */
    System.out.println("Connessione instaurata.\nPorta locale: "+ connSocket.getLocalPort() +"\nPorta remota: " + connSocket.getPort());
    /* creazione degli stream di ingresso (in) e di uscita (out) al socket di connessione */
    BufferedReader in=new BufferedReader(new InputStreamReader(connSocket.getInputStream()));
    DataOutputStream out=new DataOutputStream(connSocket.getOutputStream());
    while (! richiesta.equals("exit")) {
      richiesta=in.readLine(); /* Metodo bloccante. Legge la richiesta dallo stream bufferizzato di ingresso del socket */
      System.out.println("messaggio dal client: " + richiesta);
      risposta=richiesta.toUpperCase()+"\n"; //converte la richiesta in maiuscolo
      out.writeBytes(risposta); //invia la risposta al client
    }
    connSocket.close();
  }
}
 