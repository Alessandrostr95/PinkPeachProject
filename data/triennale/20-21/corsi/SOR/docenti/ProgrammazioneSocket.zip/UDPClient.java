/*
  Sistemi Operativi e Reti (SOR) 
  Pietro Frasca, Aprile 2014
  Lezione 11

  UDP Client
  
  1. Legge da tastiera una frase e la invia al server.
  3. Visualizza sullo schermo la risposta che ottiene dal server.  
*/
import java.io.*; 
import java.net.*; 
class UDPClient { 
  public static void main(String args[]) throws Exception{
    String nomeServer="localhost"; /* nome del server */
    int portaServer=1234; /* porta di ascolto del server */
	String richiesta = "."; 
    BufferedReader in_tastiera = new BufferedReader (new 
			InputStreamReader(System.in)) ; 
		/* Stream di ingresso: dalla tastiera al processo */
    DatagramSocket clientSocket = new DatagramSocket(); /* Socket per la connessione */
    InetAddress indirizzoIPServer = InetAddress.getByName(nomeServer); 
		/* client DNS: ritorna l'IP del server */
    while (! richiesta.equals("")) {
      System.out.print("Scrivi una frase: "); /* prompt */
      richiesta = in_tastiera.readLine(); /* metodo bloccante: legge i dati da tastiera */
      byte[] richiesta_b = richiesta.getBytes(); /* conversione di tipo String -> byte[] */
      DatagramPacket richiesta_pack = new 
	    DatagramPacket(richiesta_b,richiesta.length(),indirizzoIPServer,1234); 
			/* crea un oggetto
				DatagramPacket che conterr� i parametri passati: messaggio di richiesta,
				la dimensione del messaggio, l'indirizzo del server e la porta di ascolto del server. 
				Oltre a tali parametri il DatagramPacket conterr� altre informazioni 
				come l'indirizzo IP del client e la porta usata dal client, 
				in modo che il server una volta ottenuto il messaggio possa identificare 
				il client per inviargli una risposta */
				
      clientSocket.send(richiesta_pack); /* invia l'oggetto richiesta_pack in rete */
      byte[] risposta_b = new byte[1024]; /* array di byte per la risposta del server */
			DatagramPacket risposta_pack = new 
					DatagramPacket(risposta_b,risposta_b.length); 
					/* crea un DatagramPacket per la risposta dal server */
      clientSocket.receive(risposta_pack); 
			/* metodo bloccante: il processo si sospende fino all'arrivo della risposta dal server */ 
      String risposta = new String(risposta_pack.getData()).trim(); 
			/* estrae la risposta dal DatagramPacket che ha inviato il server e la converte in String */
      System.out.println("Risposta dal Server:" + risposta); 
			/* visualizza il messaggio di risposta */
    }  
    clientSocket.close();
  }}
